import '../app.css'

export function RightBar() {
    return (
        <div id="rigth_bar">
            <a href="https://www.gestion.ru/"><img src="/shop.webp" alt="shop" id="shop"></img></a>
        </div>
)
}

export default RightBar;
