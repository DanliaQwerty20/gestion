import { render } from 'preact'
import './index.css'
import Router from "./routing/Router.jsx";

render(
    <Router/>
    , document.getElementById('app'))
