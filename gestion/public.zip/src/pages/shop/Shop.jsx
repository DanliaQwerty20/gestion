import '../.././app.css'
import Header from "../.././header/Header.jsx";
import Footer from "../.././footer/Footer.jsx";
import LeftBar from "../.././leftBar/LeftBar.jsx";
import RightBar from "../.././rightBar/RightBar.jsx";
import {useEffect, useState} from "react";
import {ServicesService} from "../../api/services.service.js";
import axios from "axios";
import {Link} from "react-router-dom";
import Button from "../../button/Button.jsx";

export function Shop() {
    const [shopping, setShopping] = useState([])
    const [services, setServices] = useState([])

    useEffect(() => {
        const fetchData = async () => {
            const data = await axios.get("http://localhost:8080/catalog/" + ServicesService.getSessionIdFromCookies());
            setShopping(data.data)
        }

        fetchData()
    }, [])

    const handleRemove = async (id) => {
        try {
            await axios.delete(`http://localhost:8080/catalog/${id}`);
            setShopping((prevShopping) =>
                prevShopping.filter((item) => item.id !== id)
            );
        } catch (error) {
            console.error("Ошибка при удалении из корзины:", error);
        }
    };

    const totalCost = shopping.reduce(
        (accumulator, currentItem) =>
            accumulator + parseFloat(currentItem.service.price),
        0
    );

    return (
        <>
            <Header></Header>
            <div id="content">
                <LeftBar></LeftBar>
                <div id="main_content">
                    <h1 className="center_text">Корзина</h1>
                    <div id="shop_div">
                        {shopping.map(shop => (
                        <div key={shop.id} id="shop_card">
                            <img src={shop.service.photo} id="shop_img"/>
                            <div id="texting">
                                <p id="shope_name">{shop.service.name}</p>
                                <p id="shope_price">{shop.service.price}</p>
                                <span className="shope_info" id="info_text"><Link to={shop.service.url}>Подробнее об услуге</Link></span>
                            </div>
                            <button
                                id="remove_button"
                                onClick={() => handleRemove(shop.id)}
                            >
                                Удалить
                            </button>
                        </div>
                        ))}
                        <div id="right">
                            <p className="center_text">Общая Стоимость: {totalCost}</p>
                            <Link id="buy"  to={shopping.length > 0 ? '/buy' : '/service'}><button>КУПИТЬ</button></Link>
                        </div>
                    </div>
                </div>
                <RightBar></RightBar>
            </div>
            <Footer></Footer>
        </>
)
}

export default Shop;
