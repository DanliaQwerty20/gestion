import '../.././app.css'
import Header from "../.././header/Header.jsx";
import Footer from "../.././footer/Footer.jsx";
import LeftBar from "../.././leftBar/LeftBar.jsx";
import RightBar from "../.././rightBar/RightBar.jsx";

import axios from "axios";
import {useEffect, useState} from "react";
import {Link} from "react-router-dom";
import Button from "../../button/Button.jsx";
import getSessionIdFromCookies from "../../header/Header.jsx"
import {ServicesService} from "../../api/services.service.js";


export function Service() {
    const [services, setServices] = useState([])


    useEffect(() => {
        const fetchData = async () => {
            const response = await axios.get("http://localhost:8080/services")
            setServices(response.data)
        }

        fetchData()
    }, [])

    return (
        <>
            <Header></Header>
            <div id="content">
                <LeftBar></LeftBar>
                <div id="main_content">
                    <h1 className="center_text">Услуги</h1>
                    <div id="service_main">
                        {services.map(service => (
                            <div key={service.id} id="service_card">
                                <img src={service.photo} alt="абонентское юридическое обслуживание" id="service_img"/>
                                <div id="sum">
                                    <span className="dics">{service.price} ₽</span>
                                </div>
                                <p className="center_text"><b>{service.name}</b></p>
                                <span className="center_text" id="info_text"><Link to={service.url}>Подробнее об услуге</Link></span>
                                <Button serviceId={service.id}></Button>
                            </div>
                        ))}
                    </div>
                </div>
                <RightBar></RightBar>
            </div>
            <Footer></Footer>
        </>
    )
}

export default Service;