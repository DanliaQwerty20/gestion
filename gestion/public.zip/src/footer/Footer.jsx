import '../app.css'

export function Footer() {
    return (
        <footer>
            <p>Автор: Балданова Сарана</p>
            <p>sarana_mail.com</p>
            <p>© Все права защищены</p>
        </footer>
)
}

export default Footer;
